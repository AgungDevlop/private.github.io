package com.tapchat.pro;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import androidx.core.app.NotificationManagerCompat;
import android.app.RemoteInput;
import androidx.core.app.NotificationCompat;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;



public class NotificationReplyHandler {
    private Context mContext;
    private NotificationManagerCompat mNotificationManager;
    List<StatusBarNotification> notificationList = new ArrayList<>();
    
    public NotificationReplyHandler(Context context) {
        mContext = context;
        mNotificationManager = NotificationManagerCompat.from(mContext);
        
    }


// membalas pesan dari notifikasi terbaru di dalam list
public void handleNotificationReply(StatusBarNotification sbn,String replyMessage) {
    notificationList.add(sbn);
    if (!notificationList.isEmpty()) {
        StatusBarNotification latestNotification = notificationList.get(notificationList.size() - 1);
        Notification notification = latestNotification.getNotification();
        Bundle extras = notification.extras;
        if (notification.actions != null && notification.actions.length > 0) {
            RemoteInput[] remoteInputs = notification.actions[0].getRemoteInputs();
            if (remoteInputs != null && remoteInputs.length > 0) {
                RemoteInput remoteInput = remoteInputs[0];
                Intent intentSend = new Intent();
                Bundle inputResult = new Bundle();
                String notificationTime = NotificationInfo.getNotificationTime(sbn);
                // Put reply message into bundle
                inputResult.putString(remoteInput.getResultKey(), "```" + replyMessage + "\n\nReply Time :\n" + notificationTime + "```");
                // Add bundle to intent and send the reply
                RemoteInput.addResultsToIntent(remoteInputs, intentSend, inputResult);
                PendingIntent replyPendingIntent = notification.actions[0].actionIntent;
                Random r1 = new Random();
                int uniqueId0 = r1.nextInt(Integer.MAX_VALUE);
                try {
                    replyPendingIntent.send(mContext, 0, intentSend);
                    showNotification("Balasan Telah Dibuat", "Remote key :" + remoteInput.getResultKey(), uniqueId0);
                } catch (PendingIntent.CanceledException e) {
                    e.printStackTrace();
                }
            }
        }
        // menghapus notifikasi terbaru dari list
        notificationList.remove(notificationList.size() - 1);
    }
}



//Membuat Notifikasi Baru Dengan Tag Dan Key Yang sama
private void showNotification(String title, String message, int uniqueId) {
    NotificationBuilder.showNotification(mContext, title, message, uniqueId);
}



}