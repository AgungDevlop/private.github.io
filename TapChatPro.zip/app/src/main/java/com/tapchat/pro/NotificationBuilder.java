package com.tapchat.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.os.Build;

public class NotificationBuilder {
	
	private static final String CHANNEL_ID = "My_Channel_ID";
	private static final String CHANNEL_NAME = "My_Channel_Name";
	private static final String CHANNEL_DESCRIPTION = "My_Channel_Description";
	
	public static void showNotification(Context context, String title, String message, int UniqID) {
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
			channel.setDescription(CHANNEL_DESCRIPTION);
			notificationManager.createNotificationChannel(channel);
		}
		Notification notification = new Notification.Builder(context, CHANNEL_ID)
		.setContentTitle(title)
		.setContentText(message)
		.setSmallIcon(R.drawable.ic_notification)
		.build();
		notificationManager.notify(UniqID, notification);
	}
	
	public static void startForegroundN(Service service, String title, String message, int UniqID) {
		NotificationManager notificationManager = (NotificationManager) service.getSystemService(Context.NOTIFICATION_SERVICE);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
			channel.setDescription(CHANNEL_DESCRIPTION);
			notificationManager.createNotificationChannel(channel);
		}
		Notification notification = new Notification.Builder(service, CHANNEL_ID)
		.setContentTitle(title)
		.setContentText(message)
		.setSmallIcon(R.drawable.ic_notification)
		.build();
		service.startForeground(UniqID, notification);
	}
	public static void stopForegroundN(Service service, int UniqID) {
        service.stopForeground(true);
		NotificationManager notificationManager = (NotificationManager) service.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.cancel(UniqID);
	}
}
