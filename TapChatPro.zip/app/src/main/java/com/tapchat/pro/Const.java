package com.tapchat.pro;

import android.content.Context;
import android.content.SharedPreferences;

public class Const {
    public static final String PACKAGE_WHATSAPP = "com.whatsapp";
    public static final String PACKAGE_WHATSAPP_BUSINESS = "com.whatsapp.w4b";
    public static final String PACKAGE_MESSENGER = "com.facebook.orca";
    public static final String PACKAGE_TELEGRAM = "org.telegram.messenger";
    public static final long REPLY_DELAY_MS = 5000;
    public static final String ACTIVE_STATUS_KEY = "activeStatusKey";
    public static final String SHARED_PREF_NAME = "my_shared_pref";
    public static final String AUTO_REPLY = "autoReplyKey";
    public static final String TEXT_DEFAULT = "Auto Reply\nUser not available";

    public static void setActiveStatus(Context context, boolean activeStatus) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(ACTIVE_STATUS_KEY, activeStatus);
        editor.apply();
    }

    public static boolean getActiveStatus(Context context) {
        SharedPreferences preferences = getSharedPreferences(context);
        return preferences.getBoolean(ACTIVE_STATUS_KEY, false);
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
    }

    public static void setTextReply(Context context, String text) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(AUTO_REPLY, text);
        editor.apply();
    }

    public static String getTextReply(Context context) {
        SharedPreferences preferences = getSharedPreferences(context);
        return preferences.getString(AUTO_REPLY, TEXT_DEFAULT);
    }
}
