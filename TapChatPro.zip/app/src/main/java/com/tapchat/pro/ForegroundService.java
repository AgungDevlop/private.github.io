package com.tapchat.pro;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationManager;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import androidx.annotation.RequiresApi;



public class ForegroundService extends Service {
	
	private static final String CHANNEL_ID = "MyForegroundServiceChannel";
	private static final int NOTIFICATION_ID = 1221;
	
	
	@Override
	public void onCreate() {
		super.onCreate();
		
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent != null && intent.getAction() != null) {
			switch (intent.getAction()) {
				case "start":
				startForeground();
				break;
				case "stop":
				stopForeground();
				break;
			}
		}
		return START_STICKY;
	}
	
	private void startForeground() {
		Intent nintent = new Intent(this, NotificationService.class);
		startService(nintent);
		NotificationBuilder.startForegroundN(this, "Tap Chat Pro", "Running in Background", NOTIFICATION_ID);
	}  
	
	
	
	private void stopForeground() {
		NotificationBuilder.stopForegroundN(this, NOTIFICATION_ID);
		stopSelf();
	}
	
	@Nullable
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		stopForeground();
		
	}
}
