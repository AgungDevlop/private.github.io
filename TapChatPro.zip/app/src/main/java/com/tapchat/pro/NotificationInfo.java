package com.tapchat.pro;

import android.app.Notification;
import androidx.core.app.NotificationManagerCompat;
import android.os.Bundle;
import androidx.core.app.NotificationCompat;
import android.service.notification.StatusBarNotification;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Date;

public class NotificationInfo {
	
	public static class NotificationData {
		public String groupName;
		public String sender;
		public String message;
		
		public NotificationData(String groupName, String sender, String message) {
			this.groupName = groupName;
			this.sender = sender;
			this.message = message;
		}
	}
	
	public static NotificationData getNotificationData(StatusBarNotification sbn) {
		Bundle extras = sbn.getNotification().extras;
		String title = extras.getString(Notification.EXTRA_TITLE);
		String message = extras.getString(Notification.EXTRA_TEXT);
		String[] titleSplit = title != null ? title.split(": ") : null;
		
		// Check if title or sender contains "(2 messages) or more" and remove it
		if (titleSplit[0] != null) {
			// Use regular expressions to match any number of digits followed by the word "messages"
			String regex = "\\s*\\(\\d+ messages\\)$";
			String newTitle = titleSplit[0].replaceAll(regex, "").trim();
			titleSplit[0] = newTitle;
		}
		
		
		String groupName = null;
		String sender = null;
		if (titleSplit != null && titleSplit.length == 2) {
			groupName = titleSplit[0];
			sender = titleSplit[1].trim();
		} else {
			sender = title;
		}
		
		if (message == null || message.isEmpty()) {
			// Extract message text from notification extras again
			message = extras.getCharSequence("android.text").toString();
			
		}
		
		return new NotificationData(groupName, sender, message);
	}
	
	public static String getNotificationTime(StatusBarNotification sbn) {
		long notificationTime = sbn.getPostTime();
		// Set timezone to GMT+8
		TimeZone timeZone = TimeZone.getTimeZone("GMT+8");
		
		// Create date object from notificationTime
		Date date = new Date(notificationTime);
		
		// Create date formatter with desired format
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault());
		
		// Set timezone of date formatter
		simpleDateFormat.setTimeZone(timeZone);
		
		// Format date to string
		return simpleDateFormat.format(date);
	}
	
	
}
