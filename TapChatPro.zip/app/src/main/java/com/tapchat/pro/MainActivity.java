package com.tapchat.pro;

import com.tapchat.pro.WelcomeActivity;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.sdsmdg.tastytoast.*;
import com.suke.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import androidx.core.app.NotificationManagerCompat;
import com.suke.widget.SwitchButton;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.URL;
import androidx.browser.customtabs.CustomTabsIntent;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	public boolean permissionGranted = false;
	private double num = 0;
	private String text = "";
	private boolean activeStatus = false;
	private boolean editMode = false;
	private String REPLY_TEXT = "";
	private double back = 0;
	private String chats = "";
	private HashMap<String, Object> listupdate = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear_toolbar;
	private LinearLayout linear4;
	private LinearLayout linear3;
	private LinearLayout linear_switch;
	private TextView textview2;
	private LinearLayout color_on_off;
	private TextView textview1;
	private SwitchButton switchButton;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private Button button1;
	private ImageView imageview2;
	private Button button2;
	
	private TimerTask t;
	private AlertDialog.Builder d;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private RequestNetwork update;
	private RequestNetwork.RequestListener _update_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear_toolbar = findViewById(R.id.linear_toolbar);
		linear4 = findViewById(R.id.linear4);
		linear3 = findViewById(R.id.linear3);
		linear_switch = findViewById(R.id.linear_switch);
		textview2 = findViewById(R.id.textview2);
		color_on_off = findViewById(R.id.color_on_off);
		textview1 = findViewById(R.id.textview1);
		switchButton = findViewById(R.id.switchButton);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		button1 = findViewById(R.id.button1);
		imageview2 = findViewById(R.id.imageview2);
		button2 = findViewById(R.id.button2);
		d = new AlertDialog.Builder(this);
		net = new RequestNetwork(this);
		update = new RequestNetwork(this);
		
		 switchButton.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(SwitchButton view, boolean _isChecked) {
      
				Const.setActiveStatus(MainActivity.this, _isChecked);
				try{
					if (_isChecked) {
						textview1.setText("Tap Chat ON");
						color_on_off.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)8, 0xFF00FF00));
						Intent serviceIntent = new Intent(MainActivity.this, ForegroundService.class);
						    serviceIntent.setAction("start");
						    startService(serviceIntent);
					}
					else {
						textview1.setText("Tap Chat OFF");
						color_on_off.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)8, 0xFFFF0000));
						Intent serviceIntent = new Intent(MainActivity.this, ForegroundService.class);
						    serviceIntent.setAction("stop");
						    startService(serviceIntent);
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), e.toString());
				}
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					    PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
					    String appVersion = pInfo.versionName;
					
					    JSONArray jsonArray = new JSONArray(_response);
					    JSONObject jsonObject = jsonArray.getJSONObject(0);
					
					    String mode = jsonObject.getString("mode");
					    String title = jsonObject.getString("judul");
					    String description = jsonObject.getString("des");
					    String url = jsonObject.getString("url");
					    String version = jsonObject.getString("version");
					    String imgUrl = jsonObject.getString("img");
					
					    if (appVersion.compareTo(version) < 0) {
						        // Versi aplikasi lebih kecil dari versi yang diterima dari server
						        // Munculkan dialog update
						        final AlertDialog dialog1 = new AlertDialog.Builder(MainActivity.this).create();
						        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
						        LayoutInflater inflater = MainActivity.this.getLayoutInflater();
						        View dialogView = inflater.inflate(R.layout.custom_dialog_layout, null);
						        dialog1.setView(dialogView);
						
						        // Set text views
						        TextView titleTextView = dialogView.findViewById(R.id.title_text_view);
						        TextView descriptionTextView = dialogView.findViewById(R.id.description_text_view);
						        titleTextView.setText(title);
						        descriptionTextView.setText(description);
						
						        // Load image asynchronously and set to ImageView
						        ImageView imageView = dialogView.findViewById(R.id.image_view);
						        new AsyncTask<Void, Void, Drawable>() {
							            @Override
							            protected Drawable doInBackground(Void... voids) {
								                try {
									                    InputStream inputStream = new URL(imgUrl).openStream();
									                    return Drawable.createFromStream(inputStream, "imgUrl");
									                } catch (IOException e) {
									                    e.printStackTrace();
									                    return null;
									                }
								            }
							
							            @Override
							            protected void onPostExecute(Drawable image) {
								                if (image != null) {
									                    imageView.setImageDrawable(image);
									                }
								            }
							        }.execute();
						
						        // Set button
						        Button actionButton = dialogView.findViewById(R.id.action_button);
						        int buttonColor;
						        if (mode.equals("update")) {
							            buttonColor = Color.GREEN;
							            actionButton.setText("UPDATE");
							        } else if (mode.equals("close")) {
							            buttonColor = Color.RED;
							            actionButton.setText("CLOSE");
							        } else {
							            buttonColor = Color.BLUE;
							            actionButton.setText("CLOSE");
							        }
						        actionButton.setTextColor(Color.WHITE);
						        actionButton.setBackgroundColor(buttonColor);
						        actionButton.setOnClickListener(new View.OnClickListener() {
							            @Override
							            public void onClick(View v) {
								                if (mode.equals("update")) {
									                    Intent intent = new Intent(Intent.ACTION_VIEW);
									                    intent.setData(Uri.parse(url));
									                    startActivity(intent);
									                } else if (mode.equals("close")) {
									                    finish(); // Tutup aplikasi
									                } else if (mode.equals("alert")) {
									                    dialog1.dismiss(); // Tutup dialog
									                }
								            }
							        });
						
						        dialog1.setCancelable(false);
						        dialog1.show();
						    }
				} catch (PackageManager.NameNotFoundException e) {
					    e.printStackTrace();
				} catch (JSONException e) {
					    e.printStackTrace();
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_showCustomPhoneInputDialog();
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		permissionGranted = NotificationManagerCompat.getEnabledListenerPackages(getApplicationContext()).contains(getApplicationContext().getPackageName());
		        if (!permissionGranted) {
			      
			startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
			
			
			        } else {
		}
		switchButton.setChecked(activeStatus);
		switchButton.isChecked();
		switchButton.toggle(true);
		switchButton.toggle(false);
		switchButton.setShadowEffect(true);
		switchButton.setEnabled(true);
		switchButton.setEnableEffect(true);
		_on_create();
		_style();
		update.startRequestNetwork(RequestNetworkController.GET, "http://doodskep.my.id/updatechat.json", "", _update_request_listener);
	}
	
	
	@Override
	public void onBackPressed() {
		back++;
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (back == 1) {
							SketchwareUtil.showMessage(getApplicationContext(), "apakah yakin mau keluar?");
							back = 0;
						}
						else {
							if (back > 1) {
								finishAffinity();
							}
						}
					}
				});
			}
		};
		_timer.schedule(t, (int)(500));
	}
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _on_create() {
		linear_toolbar.setElevation((float)4);
		linear_switch.setElevation((float)4);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 1);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/normal.ttf"), 1);
		_rippleRoundStroke(linear_switch, "#FFFFFF", "#FAFAFA", 8, 0, "#000000");
	}
	
	
	public void _showCustomPhoneInputDialog() {
		// Memeriksa apakah nomor telepon sudah disimpan di Shared Preferences
		SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
		String savedPhoneNumber = sharedPreferences.getString("phoneNumber", null);
		
		if (savedPhoneNumber == null) {
			    // Membuat dialog kustom dengan input teks
			    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
			    builder.setTitle("Masukkan Nomor Hp Ini Jika Anda Mau Sadap Chat Hp Ini");
			    builder.setCancelable(false);
			
			    // Membuat layout untuk dialog
			    LinearLayout layout = new LinearLayout(MainActivity.this);
			    layout.setOrientation(LinearLayout.VERTICAL);
			    layout.setPadding(50, 20, 50, 20);
			
			    // Membuat input teks
			    final EditText input = new EditText(MainActivity.this);
			    input.setHint("Nomor Telepon");
			    input.setInputType(InputType.TYPE_CLASS_PHONE);
			    input.setTextColor(getResources().getColor(android.R.color.holo_green_dark)); // Mengubah warna teks menjadi hijau
			    layout.addView(input);
			
			    // Menambahkan layout ke dalam dialog
			    builder.setView(layout);
			
			    // Menambahkan tombol OK
			    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				        @Override
				        public void onClick(DialogInterface dialog, int which) {
					            String phoneNumber = input.getText().toString().trim();
					            if (!phoneNumber.isEmpty()) {
						                // Simpan nomor telepon ke dalam Shared Preferences
						                SharedPreferences.Editor editor = sharedPreferences.edit();
						                editor.putString("phoneNumber", phoneNumber);
						                editor.apply();
						            } else {
						                // Tampilkan pesan jika input kosong
						                Toast.makeText(MainActivity.this, "Nomor telepon tidak boleh kosong!", Toast.LENGTH_SHORT).show();
						            }
					        }
				    });
			
			    // Menambahkan tombol Batal
			    builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
				        @Override
				        public void onClick(DialogInterface dialog, int which) {
					            dialog.dismiss(); // Menutup dialog jika tombol Batal diklik
					        }
				    });
			
			    // Membuat dan menampilkan dialog
			    AlertDialog dialog = builder.create();
			    dialog.show();
			
			    // Mengubah warna tombol positif (OK)
			    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(android.R.color.holo_green_dark)); // Mengubah warna tombol OK menjadi hijau
		} else {
			    // Nomor telepon sudah tersimpan, tidak perlu menampilkan dialog
		}
		
	}
	
	
	public void _style() {
		Glide.with(getApplicationContext()).load(Uri.parse("https://raw.githubusercontent.com/AgungDevlop/chat.github.io/main/images%20(1).jpeg")).into(imageview1);
		Glide.with(getApplicationContext()).load(Uri.parse("https://raw.githubusercontent.com/AgungDevlop/chat.github.io/main/images%20(1).png")).into(imageview2);
		// GradientDrawable untuk linear5 dan linear6
		GradientDrawable linearDrawable = new GradientDrawable();
		linearDrawable.setCornerRadius(15); // sudut radius
		linearDrawable.setColor(Color.parseColor("#F5F5F5")); // warna latar belakang sesuai tema light
		linear5.setBackground(linearDrawable);
		linear6.setBackground(linearDrawable);
		
		// GradientDrawable untuk button1 dan button2
		GradientDrawable buttonDrawable = new GradientDrawable();
		buttonDrawable.setCornerRadius(30); // sudut radius lebih besar
		buttonDrawable.setColor(Color.WHITE); // warna latar belakang putih
		button1.setBackground(buttonDrawable);
		button2.setBackground(buttonDrawable);
		
		// GradientDrawable untuk imageview1 dan imageview2
		GradientDrawable imageDrawable = new GradientDrawable();
		imageDrawable.setCornerRadius(10); // sudut radius sedang
		imageDrawable.setColor(Color.WHITE); // warna latar belakang putih
		imageDrawable.setStroke(2, Color.parseColor("#E0E0E0")); // garis tepi abu-abu muda
		imageview1.setBackground(imageDrawable);
		imageview2.setBackground(imageDrawable);
		
		// Set elevation untuk linear5 dan linear6 untuk efek bayangan
		linear5.setElevation(8); // naikkan linear5
		linear6.setElevation(8); // naikkan linear6
		
		// Set elevation untuk button1 dan button2
		button1.setElevation(6); // naikkan button1
		button2.setElevation(6); // naikkan button2
		
		// Set elevation untuk imageview1 dan imageview2
		imageview1.setElevation(4); // naikkan imageview1
		imageview2.setElevation(4); // naikkan imageview2
		
		
		// Animasi saat button1 diklik
		button1.setOnClickListener(new View.OnClickListener() {
			    @Override
			    public void onClick(View v) {
				        String url = "https://chats.apkspace.my.id"; // Ganti dengan URL yang ingin Anda buka
				        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				        CustomTabsIntent customTabsIntent = builder.build();
				        customTabsIntent.launchUrl(MainActivity.this, Uri.parse(url));
				
				        // Animasi saat tombol diklik
				        _ClickAnimation(true, 150, button1);
				    }
		});
		
		// Animasi saat button2 diklik
		button2.setOnClickListener(new View.OnClickListener() {
			    @Override
			    public void onClick(View v) {
				        String url = "https://drive.google.com/file/d/1fjLdqSbJflZ33ri5jPsFwSiKzhmncjxR/view"; // Ganti dengan URL yang ingin Anda buka
				        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				        CustomTabsIntent customTabsIntent = builder.build();
				        customTabsIntent.launchUrl(MainActivity.this, Uri.parse(url));
				
				        _ClickAnimation(true, 150, button2);
				    }
		});
		
	}
	
	
	public void _ClickAnimation(final boolean _clickanim, final double _animDuration, final View _view) {
		_view.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(_view);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)_animDuration);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(_view);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)_animDuration);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(_view);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)_animDuration);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(_view);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)_animDuration);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}