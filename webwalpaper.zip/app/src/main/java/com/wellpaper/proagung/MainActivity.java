package com.wellpaper.proagung;

import com.wellpaper.proagung.SplashActivity;
import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.cyberalpha.darkIOS.*;
import com.daimajia.numberprogressbar.*;
import com.google.android.gms.ads.MobileAds;
import com.sdsmdg.tastytoast.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import androidx.documentfile.provider.DocumentFile;
import android.provider.DocumentsContract;
import android.database.*;
import android.provider.DocumentsContract.Document;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String path = "";
	private String path2 = "";
	private double sumCount = 0;
	private double size = 0;
	private String result = "";
	private String filename = "";
	private double back = 0;
	InterstitialAd intermusic;
	
	private LinearLayout admobads;
	private LinearLayout linear1;
	private LinearLayout progresslinear;
	private WebView webview1;
	private ImageView imageview1;
	private Button button1;
	private LinearLayout linear2;
	private NumberProgressBar progressbar1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	private ImageView imageview5;
	
	private TimerTask t;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		MobileAds.initialize(this);
		
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		admobads = findViewById(R.id.admobads);
		linear1 = findViewById(R.id.linear1);
		progresslinear = findViewById(R.id.progresslinear);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		imageview1 = findViewById(R.id.imageview1);
		button1 = findViewById(R.id.button1);
		linear2 = findViewById(R.id.linear2);
		progressbar1 = findViewById(R.id.progressbar1);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		imageview5 = findViewById(R.id.imageview5);
		dialog = new AlertDialog.Builder(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.setVisibility(View.VISIBLE);
				imageview1.setVisibility(View.GONE);
				button1.setVisibility(View.GONE);
				linear2.setVisibility(View.VISIBLE);
				WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
				try {
					Bitmap bitmap = ((android.graphics.drawable.BitmapDrawable) imageview1.getDrawable()).getBitmap();
					wallpaperManager.setBitmap(bitmap);
				}
				catch (Exception g) {
					g.printStackTrace();
				}
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_InterstitialAd();
								TastyToast.makeText(getApplicationContext(), "Set Wallpapers Sucess... ", TastyToast.LENGTH_LONG, TastyToast.SUCCESS);
								FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat(path2));
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl("https://www.google.com/webhp?output=search&tbm=isch&tbo=u&sa=X&ved=0ahUKEwjT4OaqgPb5AhXsxnMBHYrPAIYQ0tQDCBUoAQ");
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.reload();
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.goBack();
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.goForward();
			}
		});
	}
	
	private void initializeLogic() {
		
		
		AdView admobads_adView = new AdView(MainActivity.this);
		
		admobads_adView.setAdSize(AdSize.BANNER);
		        admobads_adView.setAdUnitId("ca-app-pub-8084734803707655/1244254125");
		        admobads.addView(admobads_adView);
		        
		        AdRequest admobads_req = new            AdRequest.Builder().build();
		   admobads_adView.loadAd(admobads_req);
		
		
		_ClickAnimation(true, 150, button1);
		path2 = "/Download/image.png";
		imageview1.setVisibility(View.GONE);
		progresslinear.setVisibility(View.GONE);
		button1.setVisibility(View.GONE);
		linear2.setVisibility(View.VISIBLE);
		webview1.loadUrl("https://www.google.com/webhp?output=search&tbm=isch&tbo=u&sa=X&ved=0ahUKEwjT4OaqgPb5AhXsxnMBHYrPAIYQ0tQDCBUoAQ");
		{
				webview1.setOnLongClickListener(new View.OnLongClickListener() {
									 @Override
										public boolean onLongClick(final View v) {
								
								        
								WebView.HitTestResult result = ((WebView)v).getHitTestResult();
								                if (null == result)
								                    return false;
								                int type = result.getType();
								                if (type == WebView.HitTestResult.UNKNOWN_TYPE) { return false;
										                    
										                }
								                
								                if (WebView.HitTestResult.IMAGE_TYPE == type) {
										
										final String imageUrl = result.getExtra();
						
						DownloadManager.Request request = new DownloadManager.Request(Uri.parse(imageUrl));
													            request.allowScanningByMediaScanner();
																				              													   
										
										iOSDarkBuilder dialog = new iOSDarkBuilder(MainActivity.this);
						dialog
						.setTitle("INFORMATION")
						.setSubtitle("Do you want to use this as a wallpaper?") 	
							.setCancelable(false)
						.setNegativeListener("NO",new iOSDarkClickListener() 
						{ 	 @Override 	 public void onClick(iOSDark dialog) { 		
								dialog.dismiss(); 	
								}
						})
						.setPositiveListener("YES",new iOSDarkClickListener() 
						{ 	 @Override 	 public void onClick(iOSDark dialog) { 		
										new DownloadTask().execute(imageUrl);
								dialog.dismiss(); 	
								}
						})	
						.build().show();
						
																												              	   						                
							}				                	
								
												return false;
										}
									 });
							 
							 }
		webview1.setOverScrollMode(View.OVER_SCROLL_NEVER); webview1.setVerticalScrollBarEnabled(false); webview1.setHorizontalScrollBarEnabled(false); webview1.setScrollbarFadingEnabled(true); webview1.getSettings().setJavaScriptEnabled(true);  webview1.getSettings().setAllowFileAccess(true);  webview1.getSettings().setLoadWithOverviewMode(false); webview1.getSettings().setUseWideViewPort(true); webview1.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN); webview1.getSettings().setDomStorageEnabled(true); webview1.getSettings().setSaveFormData(true);
		webview1.setWebViewClient(new WebViewClient()
		{
					  public boolean shouldOverrideUrlLoading(WebView view, String url)
					  {
								    String
				bali="https://www.google.com"; 
				
				//
				
				if (url != null && url.startsWith(bali)){
											      return false; }
								     
								    else
								    {
											    view.getContext().startActivity(
											      new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
											      return true;
											    }
								  }
		});
		webview1.setWebChromeClient(new WebChromeClient() {
				@Override
				public boolean onShowFileChooser(WebView webView, ValueCallback filePathCallback, FileChooserParams fileChooserParams) {
						mFilePathCallback = filePathCallback;
						Intent intent = new Intent(Intent.ACTION_GET_CONTENT); intent.setType("*/*"); startActivityForResult(intent, PICKFILE_REQUEST_CODE);
						return true;
				}
		});
	}
	private ValueCallback <Uri[]> mFilePathCallback;
	private static final int PICKFILE_REQUEST_CODE = 0;
	
	@Override protected void onActivityResult(int requestCode, int resultCode, Intent intent) { if (requestCode == PICKFILE_REQUEST_CODE) { Uri result = intent == null || resultCode != RESULT_OK ? null : intent.getData();
				Uri[] resultsArray = new Uri[1];
				resultsArray[0] = result;
				mFilePathCallback.onReceiveValue(resultsArray); }
		MobileAds.registerWebView(webview1);
	}
	
	@Override
	public void onBackPressed() {
		back++;
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (back == 1) {
							back = 0;
							SketchwareUtil.showMessage(getApplicationContext(), "Press again to exit");
						}
						else {
							if (back > 1) {
								finishAffinity();
							}
						}
					}
				});
			}
		};
		_timer.schedule(t, (int)(500));
	}
	
	@Override
	public void onResume() {
		super.onResume();
		getWindow().getDecorView()
		.setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_InterstitialAd();
	}
	
	public void _extra() {
	}
	
	private class DownloadTask extends AsyncTask<String, Integer, String> {
		
		
		 @Override
		
		protected void onPreExecute() {
			
			
			progresslinear.setVisibility(View.VISIBLE);
		}
		protected String doInBackground(String... address) {
			try {
				filename= URLUtil.guessFileName(address[0], null, null);
				int resCode = -1;
				java.io.InputStream in = null;
				java.net.URL url = new java.net.URL(address[0]);
				java.net.URLConnection urlConn = url.openConnection();
				if (!(urlConn instanceof java.net.HttpURLConnection)) {
					throw new java.io.IOException("URL is not an Http URL"); }
				java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
				resCode = httpConn.getResponseCode();
				if (resCode == java.net.HttpURLConnection.HTTP_OK) {
					in = httpConn.getInputStream();
					size = httpConn.getContentLength();
					
				} else { result = "There was an error"; }
				path = FileUtil.getExternalStorageDir().concat("/Download/".concat("image.png"));
				FileUtil.writeFile(path, "");
				java.io.File file = new java.io.File(path);
				
				java.io.OutputStream output = new java.io.FileOutputStream(file);
				try {
					int bytesRead;
					sumCount = 0;
					byte[] buffer = new byte[1024];
					while ((bytesRead = in.read(buffer)) != -1) {
						output.write(buffer, 0, bytesRead);
						sumCount += bytesRead;
						if (size > 0) {
							publishProgress((int)Math.round(sumCount*100 / size));
						}
					}
				} finally {
					output.close();
				}
				result ="";
				in.close();
			} catch (java.net.MalformedURLException e) {
				result = e.getMessage();
			} catch (java.io.IOException e) {
				result = e.getMessage();
			} catch (Exception e) {
				result = e.toString();
			}
			return result;
			
		}
		protected void onProgressUpdate(Integer... values) {progressbar1.setProgress(values[values.length - 1]);
			
		}
		protected void onPostExecute(String s){
			
			showMessage(s);
			progresslinear.setVisibility(View.GONE);
			t = new TimerTask() {
					@Override
					public void run() {
							runOnUiThread(new Runnable() {
									@Override
									public void run() {
							imageview1.setVisibility(View.VISIBLE);
							button1.setVisibility(View.VISIBLE);	imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getExternalStorageDir().concat(path2), 1024, 1024));
							webview1.setVisibility(View.GONE);  
							linear2.setVisibility(View.GONE);
									}
							});
					}
			};
			_timer.schedule(t, (int)(3000));
		}
	}
	
	
	public void _ClickAnimation(final boolean _clickanim, final double _animDuration, final View _view) {
		_view.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(_view);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)_animDuration);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(_view);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)_animDuration);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(_view);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)_animDuration);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(_view);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)_animDuration);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
	}
	
	
	public void _InterstitialAd() {
		AdRequest intermusic_req = new AdRequest.Builder().build();
		
		        InterstitialAd.load(MainActivity.this,"ca-app-pub-8084734803707655/6305009111", intermusic_req,
		new InterstitialAdLoadCallback() {
					
					                                 @Override
					                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
								
								
								                        intermusic = interstitialAd;
								
								intermusic.show(MainActivity.this);
								
								                    }
					                  
					  @Override
					                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
								
								
								                        intermusic = null;
								 
								                    }
					                });
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}